package controlador;

public class Controllador {

}
