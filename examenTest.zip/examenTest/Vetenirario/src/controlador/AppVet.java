package controlador;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import vista.DNIchecker;

public class AppVet extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private String Nombre;
	private String Apellido;
	private String DNI;
	
	private String Fecha;
	
	private String Hora;
	
	
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	
	private JTextField textField_3;
	
	private JTextField textField_6;
	
	DNIchecker DNIlist;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AppVet frame = new AppVet();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AppVet() {
		setTitle("Establezador De Cita Para El Vetenario");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 552, 552);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nombre: ");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel.setBounds(10, 21, 100, 31);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Apellido: ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(10, 63, 100, 31);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("DNI: ");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1_1.setBounds(10, 105, 100, 31);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Fecha: ");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1_2.setBounds(10, 174, 100, 31);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3_1_1 = new JLabel("Hora: ");
		lblNewLabel_1_3_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1_3_1_1.setBounds(10, 216, 100, 31);
		contentPane.add(lblNewLabel_1_3_1_1);
		
		JTextArea textArea = new JTextArea();
		textArea.setEditable(false);
		textArea.setBounds(320, 21, 177, 445);
		contentPane.add(textArea);
		textArea.setLineWrap(true);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField.setBounds(120, 25, 170, 27);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField_1.setColumns(10);
		textField_1.setBounds(120, 65, 170, 27);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField_2.setColumns(10);
		textField_2.setBounds(120, 107, 170, 27);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField_3.setColumns(10);
		textField_3.setBounds(120, 176, 170, 27);
		contentPane.add(textField_3);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField_6.setColumns(10);
		textField_6.setBounds(120, 218, 170, 27);
		contentPane.add(textField_6);
		
		JButton btnNewButton = new JButton("Añadir Datos");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Nombre = textField.getText();
				Apellido = textField_1.getText();
				DNI = textField_2.getText();
				
				Fecha = textField_3.getText();
				
				Hora = textField_6.getText();
				
				if (Fecha.matches("-?\\d+(\\.\\d+)?")) {
					
					textArea.setText(Nombre + " " + Apellido + "    " + DNI + "    " + Fecha + "    " + Hora);
				}
				
				else {
					System.out.println("has no number");
				}
				
				for (int i = 0 ;i <= 2;i++) {
					switch(i) {
					case 1:
						Fecha.matches("-?\\d+(\\.\\d+)?");
					}
				}
				
				
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton.setBounds(39, 437, 251, 40);
		contentPane.add(btnNewButton);
	}

}
