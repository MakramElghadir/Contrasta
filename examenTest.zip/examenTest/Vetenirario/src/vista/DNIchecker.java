package vista;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import controlador.AppVet;

public class DNIchecker implements Serializable {
		private List<String> DNIlist = new ArrayList<String>();
		private AppVet vista;
		
		
		
		public static void controlador(AppVet vista) {
			AppVet vista1 = vista;
			ArrayList<String> DNIlist = new ArrayList<String>();
		}



		@Override
		public String toString() {
			return "DNIchecker [DNIlist=" + DNIlist + ", vista=" + vista + "]";
		}



		public List<String> getDNIlist() {
			return DNIlist;
		}



		public void setDNIlist(List<String> dNIlist) {
			DNIlist = dNIlist;
		}



		public AppVet getVista() {
			return vista;
		}



		public void setVista(AppVet vista) {
			this.vista = vista;
		}
}
