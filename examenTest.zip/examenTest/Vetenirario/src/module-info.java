/**
 * 
 */
/**
 * 
 */
module Vetenirario {
	requires java.desktop;
}