package vista;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DNIchecker implements Serializable {
		public List<String> DNIlist = new ArrayList<String>();
		
}
